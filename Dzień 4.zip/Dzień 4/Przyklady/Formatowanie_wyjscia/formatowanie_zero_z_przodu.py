for i in range(1, 10):
    print('{:03}'.format(i))
    print(f'{i:03}')
