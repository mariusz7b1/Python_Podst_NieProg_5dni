from math import ceil, floor, trunc
from math import pi as PI

x = 1.4
y = PI

print(floor(x), floor(y))
print(floor(-x), floor(-y))

print(ceil(x), ceil(y))
print(ceil(-x), ceil(-y))

print(trunc(x), trunc(y))
print(trunc(-x), trunc(-y))
