import os
if os.path.exists("ksiazkaa.txt"):
    print("Plik istnieje")
else:
    print("plik nie istnieje")
input()
