""" implementacja ppopularnej w latach 70-80 :) gry pomidor
    w erze przed smartfonowej
"""
from os import system
system('cls')

slowo = 'pomidor'
while slowo == 'pomidor':
    slowo = input('podaj slowo: ')
