#Zadanie 1
print()
print("Zadanie 1")
x=int(input("podaj liczbę całkowitą x: "))
print("Potega 2: " + str(x**2))
print("Potega 3: " + str(x**3))
print("Potega 4: " + str(x**4))

#Zadanie 2
print()
print("Zadanie 2")
x=float(input("podaj liczbę rzeczywistą x: "))
print("Połowa liczby to: " + str(x/2))

#zadanie 3
print()
print("Zadanie 3")
a=int(input("podaj liczbę całkowitą a: "))
b=float(input("podaj liczbę rzeczywistą b: "))
print(str(float(a) + b))

#Zadanie 4
print()
print("Zadanie 4")
print("Ciąg znaków ma :"+str(len(input("Podaj ciąg znaków :")))+" znaków")

#Zadanie 5
print()
print("Zadanie 5")
x=float(input("podaj liczbę rzeczywistą: "))
print(round(x))

#Zadanie 6
print()
print("Zadanie 6")
a=int(input("podaj liczbę całkowitą a: "))
b=int(input("podaj liczbę całkowitą b: "))
print("Średnia arytmetyczna to: " + str((float(a)+float(b))/2))

#Zadanie 7
print()
print("Zadanie 7")
a=float(input("podaj liczbę a: "))
b=float(input("podaj liczbę b: "))
c=float(input("podaj liczbę c: "))
print(max(a,b,c))
print(min(a,b,c))
print((a+b+c)/3)


