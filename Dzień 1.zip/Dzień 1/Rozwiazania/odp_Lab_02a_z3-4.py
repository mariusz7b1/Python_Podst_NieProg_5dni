"""
Lista 02a Zadanie 3 i 4
"""
from os import system
system('cls')

# Zadanie 3
wiek = int(input("Podaj swój wiek: "))
if wiek >= 18:
    print("Jesteś pełnoletni")
else:
    print("Nie jesteś pełnoletni")

# Zadanie 4
temperatura = int(input("Podaj temperaturę: "))
if temperatura < 0:
    print("Temperatura poniżej zera")
elif temperatura > 0:
    print("Temperatura powyżej zera")
else:
    print("Temperatura wynosi zero")
