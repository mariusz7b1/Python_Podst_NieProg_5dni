print()
print('Twoja ksywa to\n\t"Tiger"\n', "znaczy sie 'Tygrys'")
input()
